var socket = io.connect('192.168.42.19:3000')


var app = new Vue({
    el: '#app',
    data: {
        trigger: false
    },
    methods: {
        onTrigger: function(){
            this.trigger = !this.trigger
            socket.emit('trigger', {
                state: this.trigger
            })
        }
    }
})